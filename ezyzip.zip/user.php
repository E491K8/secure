<?php

include("config.php");
date_default_timezone_set("Asia/Calcutta");

$email = "pawan94vip@gmail.com";
$ssid = mt_rand(000000000, 999999999);
$password = md5("Pawan@2244");
$mobile = "+919546730793";

$sql = "INSERT INTO admin (email, ssid, mobile, password)
VALUES ('$email', '$ssid', '$mobile', '$password')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


?>