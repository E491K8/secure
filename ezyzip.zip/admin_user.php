<?php

include("config.php");
date_default_timezone_set("Asia/Calcutta");

$mobile = "+919546730793";
$email = "confict.con@gmail.com";
$name = "Pawan Kumar";
$service = "OPTIONS";
$account = "10074161132";
$ifsc = "SBIN0001353";
$balance = "4987";
$aadhar = "715812446393";
$status = "Active";
$kbs_id = mt_rand(000000000, 999999999);
$request = "Update my mobile number to 8899687924";
$date = date('Y-m-d H:i:s');


$sql = "INSERT INTO transact (name, email, mobile, service, time, request, account, ifsc, stat, balance, aadhar, kbs_id)
VALUES ('$name', '$email', '$mobile', '$service', '$date', '$request', '$account', '$ifsc', '$status', '$balance', '$aadhar', '$kbs_id')";

if(mysqli_query($conn, $sql)){
  echo "Records inserted successfully.";
} else{
  echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

$conn->close();


?>