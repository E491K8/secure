<?php
include "config.php";
date_default_timezone_set("Asia/Calcutta");

session_start();

$otp = mt_rand(000000, 999999);
$email = $_SESSION['SESSION_SSID'];

$sql = "UPDATE admin SET otp='$otp' WHERE email='$email'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
  $_SESSION["SESSION_NEW_SSID"] = $email;
  $_SESSION["SESSION_OTP"] = $otp;
  header("Location: sms.php");

} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>